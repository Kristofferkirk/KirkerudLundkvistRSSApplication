﻿using System;
using Logic.Exceptions;

namespace Logic.Service.Validation
{
    public class UrlValidator
    {
        public bool Validate(string url)
        {
            throw new NotImplementedException();
        }
    }
}
using System;

namespace Logic.Entities
{
    public class FeedItem
    {
        public string Id { get; set; }
        public string Title { get; set; }
    }
}
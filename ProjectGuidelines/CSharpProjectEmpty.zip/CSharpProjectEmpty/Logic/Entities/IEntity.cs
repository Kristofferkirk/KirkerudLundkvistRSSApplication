﻿using System;

namespace Logic.Entities
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}
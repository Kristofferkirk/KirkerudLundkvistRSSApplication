﻿using System;

namespace Logic.Exceptions
{
    public class ValidationException : Exception
    {

    }
}
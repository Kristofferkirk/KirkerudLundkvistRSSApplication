﻿using System;
using System.Collections.Generic;
using Logic.Entities;

namespace Logic.Readers
{
    internal class RssReader : IReader
    {
        public IEnumerable<FeedItem> Read(string url)
        {
            throw new NotImplementedException();
        }
    }
}
